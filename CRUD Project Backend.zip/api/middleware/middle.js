



    // let user1=await userModel.findByIdAndUpdate(userid,{
    //     name:name,
    //     age:age,
    //     email:email,
    //     password:password
    // },{ new: true })
    // console.log("updated user");
    // console.log(user1);
    // return res.status(200).json({
    //     message:"update",
    //     user1
    // })