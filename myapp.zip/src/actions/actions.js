export const upadte_data=()=>{
    
    return {type:"update"}

};