function Home() {



    return (<div>


<h1>waqas ahmad</h1>

    </div>  );
}

export default Home;