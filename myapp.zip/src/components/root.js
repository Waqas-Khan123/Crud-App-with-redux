import { combineReducers } from "redux";
import { Update } from "./../reducers/reduc1";

 const rootReducer = combineReducers({
  Update,
});

export default rootReducer;
